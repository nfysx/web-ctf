<?php
// 站点配置（生产环境）
$SITE_NAME  = '星记';
$DB_HOST    = '127.0.0.1';
$DB_USER    = 'note_user';
$DB_PASS    = 'Note@2026';
$DB_NAME    = 'note_db';

// 调试口令（运维要求上线前删掉，一直没删）
$DEBUG_TOKEN = 'sk-9f2c1a7b';
