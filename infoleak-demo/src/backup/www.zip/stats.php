<?php $id=$_GET['id']??'1'; $raw=file_get_contents(__DIR__.'/data/visit-'.$id.'.json'); ?>
